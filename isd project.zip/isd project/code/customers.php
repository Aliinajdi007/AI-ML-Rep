<?php
include "header.php";
include "connection.php";

$user_id = $_SESSION['user_id'];

if (isset($_POST['add_customer'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $insert_sql = "INSERT INTO customers (name, email, phone, address, user_id) 
                   VALUES ('$name', '$email', '$phone', '$address', '$user_id')";
    
    if ($conn->query($insert_sql) === TRUE) {
        echo "<div class='alert alert-success'>Customer added successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}


if (isset($_POST['update_customer'])) {
    $customer_id = $_POST['customer_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $update_sql = "UPDATE customers SET 
                   name = '$name', 
                   email = '$email', 
                   phone = '$phone', 
                   address = '$address' 
                   WHERE id = '$customer_id' AND user_id = '$user_id'";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success'>Customer updated successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    $check_sql = "SELECT COUNT(*) as used_count FROM purchase WHERE customer_id = '$delete_id' AND user_id = '$user_id'
                  UNION ALL
                  SELECT COUNT(*) as used_count FROM sales WHERE soldto = '$delete_id' AND user_id = '$user_id'";
    $check_result = $conn->query($check_sql);
    $is_used = false;
    
    if ($check_result && $check_result->num_rows > 0) {
        while ($row = $check_result->fetch_assoc()) {
            if ($row['used_count'] > 0) {
                $is_used = true;
                break;
            }
        }
    }
    
    if ($is_used) {
        echo "<div class='alert alert-warning'>This customer cannot be deleted because they are referenced in purchases or sales records.</div>";
    } else {
        $delete_sql = "DELETE FROM customers WHERE id = '$delete_id' AND user_id = '$user_id'";
        if ($conn->query($delete_sql) === TRUE) {
            echo "<div class='alert alert-success'>Customer deleted successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
        }
    }
}

$customers_sql = "SELECT * FROM customers WHERE user_id = '$user_id'";
$customers_result = $conn->query($customers_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Customers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .edit-form {
            display: none;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5>Add New Customer</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone">
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" name="add_customer">Add Customer</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Customer List</h5>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($customers_result && $customers_result->num_rows > 0) {
                                while ($customer = $customers_result->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td><?php echo $customer['name']; ?></td>
                                        <td><?php echo $customer['email']; ?></td>
                                        <td><?php echo $customer['phone']; ?></td>
                                        <td><?php echo $customer['address']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary edit-btn" 
                                                    data-id="<?php echo $customer['id']; ?>"
                                                    data-name="<?php echo $customer['name']; ?>"
                                                    data-email="<?php echo $customer['email']; ?>"
                                                    data-phone="<?php echo $customer['phone']; ?>"
                                                    data-address="<?php echo $customer['address']; ?>">
                                                Edit
                                            </button>
                                            <a href="?delete_id=<?php echo $customer['id']; ?>" class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this customer?')">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='5'>No customers found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post">
                        <input type="hidden" id="edit_customer_id" name="customer_id">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="edit_name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="edit_phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="edit_phone" name="phone">
                        </div>
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit_address" name="address" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" name="update_customer">Update Customer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get all edit buttons
    const editButtons = document.querySelectorAll('.edit-btn');
    
    // Add click event to each edit button
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get customer data from button attributes
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const email = this.getAttribute('data-email');
            const phone = this.getAttribute('data-phone');
            const address = this.getAttribute('data-address');
            
            // Set modal form values
            document.getElementById('edit_customer_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_email').value = email;
            document.getElementById('edit_phone').value = phone;
            document.getElementById('edit_address').value = address;
            
            // Open the modal
            const editModal = new bootstrap.Modal(document.getElementById('editModal'));
            editModal.show();
        });
    });
});
</script>
</body>
</html>