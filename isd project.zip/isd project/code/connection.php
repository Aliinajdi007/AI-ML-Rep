<?php
$servername = "sql307.infinityfree.com";
$username = "if0_38918381";
$password = "Givd6LBuZii";
$dbname = "if0_38918381_ims480";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>