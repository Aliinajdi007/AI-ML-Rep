<?php
include "header.php";
include "connection.php";

$user_id = $_SESSION['user_id'];


$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

$where_clause = "WHERE user_id = '$user_id'";
if (!empty($start_date) && !empty($end_date)) {
    $where_clause .= " AND purchasedate BETWEEN '$start_date' AND '$end_date'";
    $sales_where_clause = " AND saledate BETWEEN '$start_date' AND '$end_date'";
} else {
    $sales_where_clause = "";
}


$purchase_sql = "SELECT SUM(unit * unitprice) AS total_purchase FROM purchase $where_clause";
$purchase_result = $conn->query($purchase_sql);
$total_purchase = $purchase_result->fetch_assoc()['total_purchase'] ?? 0;

$sales_sql = "SELECT SUM(sellunit * saleprice) AS total_sales FROM sales WHERE user_id = '$user_id' $sales_where_clause";
$sales_result = $conn->query($sales_sql);
$total_sales = $sales_result->fetch_assoc()['total_sales'] ?? 0;

$profit = $total_sales - $total_purchase;


if (isset($_GET['export']) && $_GET['export'] === "1") {
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=business_report.csv");
    echo "Type,Amount\n";
    echo "Total Purchase,$total_purchase\n";
    echo "Total Sales,$total_sales\n";
    echo ($profit >= 0 ? "Profit" : "Loss") . ",$profit\n";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Business Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .summary-card {
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.08);
            padding: 25px;
            background: #ffffff;
        }
        .profit-positive {
            color: green;
        }
        .profit-negative {
            color: red;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <h2 class="mb-4 text-center">Business Overview Report</h2>

    <form class="row g-3 mb-4" method="get">
        <div class="col-md-3">
            <label for="start_date" class="form-label">Start Date</label>
            <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
        </div>
        <div class="col-md-3">
            <label for="end_date" class="form-label">End Date</label>
            <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
        </div>
        <div class="col-md-6 d-flex align-items-end gap-2">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="?start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>&export=1" class="btn btn-success">Export Report</a>
        </div>
    </form>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="summary-card">
                <h6>Total Purchase</h6>
                <h4 class="text-danger">$<?php echo number_format($total_purchase, 2); ?></h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <h6>Total Sales</h6>
                <h4 class="text-primary">$<?php echo number_format($total_sales, 2); ?></h4>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <h6><?php echo ($profit >= 0) ? "Profit" : "Loss"; ?></h6>
                <h4 class="<?php echo ($profit >= 0) ? 'profit-positive' : 'profit-negative'; ?>">
                    $<?php echo number_format(abs($profit), 2); ?>
                </h4>
            </div>
        </div>
    </div>

    <div class="card p-4 shadow-sm">
        <h5 class="mb-3">Sales vs Purchase Chart</h5>
        <canvas id="reportChart" height="120"></canvas>
    </div>
</div>

<script>
const ctx = document.getElementById('reportChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Purchase', 'Sales', '<?php echo ($profit >= 0) ? "Profit" : "Loss"; ?>'],
        datasets: [{
            label: 'USD ($)',
            data: [<?php echo $total_purchase; ?>, <?php echo $total_sales; ?>, <?php echo abs($profit); ?>],
            backgroundColor: [
                'rgba(255, 99, 132, 0.6)',
                'rgba(54, 162, 235, 0.6)',
                '<?php echo ($profit >= 0) ? "rgba(75, 192, 192, 0.6)" : "rgba(255, 159, 64, 0.6)"; ?>'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                '<?php echo ($profit >= 0) ? "rgba(75, 192, 192, 1)" : "rgba(255, 159, 64, 1)"; ?>'
            ],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '$' + value;
                    }
                }
            }
        },
        plugins: {
            legend: { display: false }
        }
    }
});
</script>
</body>
