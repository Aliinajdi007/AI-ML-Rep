-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql307.infinityfree.com
-- Generation Time: May 07, 2025 at 01:31 PM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_38918381_ims480`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `user_id`, `created_at`) VALUES
(1, 'ali najdi', 'a@gmail.com', '71862750', 'ss', 6, '2025-05-07 16:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `unit` int(100) NOT NULL,
  `unitprice` int(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `des`, `unit`, `unitprice`, `created_at`, `user_id`) VALUES
(16, 'زيت زيتون', 'زيت زيتون بكر ممتاز', 0, 25, '2025-05-01 08:00:00', 1),
(17, 'سكر', 'سكر نقي', 0, 2, '2025-05-01 09:00:00', 1),
(18, 'ملح', 'ملح طبيعي 100%', 0, 2, '2025-05-01 10:00:00', 1),
(19, 'دقيق قمح', 'دقيق قمح عالي الجودة', 0, 4, '2025-05-01 11:00:00', 1),
(20, 'ماء معدني', 'ماء نقي من الينابيع', 0, 1, '2025-05-01 12:00:00', 1),
(21, 'شاي', 'شاي أخضر فاخر', 0, 7, '2025-05-01 13:00:00', 1),
(22, 'قهوة', 'قهوة سريعة التحضير', 0, 5, '2025-05-01 14:00:00', 1),
(23, 'مكسرات', 'مكسرات متنوعة', 0, 15, '2025-05-01 15:00:00', 1),
(24, 'حليب', 'حليب طازج كامل الدسم', 0, 3, '2025-05-01 16:00:00', 1),
(40, 'Hudabeuty', 'Mamaknn', 77, 7188, '2025-05-06 19:18:29', 3);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `des` varchar(100) NOT NULL,
  `unit` int(100) NOT NULL,
  `unitprice` int(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL DEFAULT 1,
  `purchasedate` date DEFAULT NULL,
  `purchasedfrom` varchar(255) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `name`, `des`, `unit`, `unitprice`, `created_at`, `user_id`, `purchasedate`, `purchasedfrom`, `customer_id`) VALUES
(0, 'Pepsi 250ml', '400gr', 1000, 1, '2025-05-01 13:03:33', 2, '2025-05-01', NULL, 5),
(0, 'Pepsi 250ml', '400gr', 2, 555, '2025-05-06 16:47:05', 2, '2025-05-07', NULL, 5),
(0, 'kisolin', 'diet', 55, 5959, '2025-05-06 16:47:26', 2, '2025-05-13', NULL, 8),
(0, 'kisolin', '400gr', 55, 4, '2025-05-06 16:54:15', 2, '2025-05-16', NULL, 5),
(0, 'lio', '400gr', 55, 11, '2025-05-06 16:57:08', 2, '2025-05-05', NULL, 7),
(0, 'lio', 'diet', 10, 111, '2025-05-06 16:57:42', 2, '2025-05-14', NULL, 7),
(0, 'water', '400gr', 10, 10, '2025-05-06 17:02:01', 2, '2025-05-13', NULL, 6),
(0, 'water', '400gr', 10, 15, '2025-05-06 17:02:22', 2, '2025-05-20', NULL, 7),
(0, 'water', '400gr', 10, 100, '2025-05-06 17:03:18', 2, '2025-05-22', NULL, 7),
(0, 'Hudabeuty', 'Mamaknn', 77, 7188, '2025-05-06 19:18:29', 3, '2025-05-20', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sellunit` int(100) NOT NULL,
  `totalprice` int(100) NOT NULL,
  `productid` int(100) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `user_id` int(11) NOT NULL DEFAULT 1,
  `soldto` varchar(255) DEFAULT NULL,
  `saleprice` decimal(10,2) DEFAULT NULL,
  `saledate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `name`, `sellunit`, `totalprice`, `productid`, `created_at`, `user_id`, `soldto`, `saleprice`, `saledate`) VALUES
(10, 'Pepsi 250ml', 1000, 1250, 14, '2025-05-01 13:03:51.767852', 2, '6', '1.25', NULL),
(11, 'Pepsi 250ml', 2, 2000, 35, '2025-05-06 16:47:40.500916', 2, '6', '1000.00', NULL),
(12, 'kisolin', 55, 5500000, 36, '2025-05-06 16:48:46.717538', 2, '8', '100000.00', NULL),
(13, 'kisolin', 55, 2147483647, 37, '2025-05-06 16:54:28.684790', 2, '6', '99999999.99', NULL),
(14, 'water', 30, 2147483647, 39, '2025-05-06 17:03:48.302080', 2, '5', '99999999.99', NULL),
(15, 'زيت زيتون', 10, 150, 16, '2025-05-07 14:40:34.836587', 1, '4', '15.00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'ali', '0000'),
(2, 'ahmad', '0000'),
(3, 'fatouma', '0'),
(4, 'kiko', '0000'),
(6, 'Hadi', '123'),
(9, 'alii', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
